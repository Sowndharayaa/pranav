module.exports = function(api) {
  api.cache(true);
  return {
    pets: ['babel-preset-expo'],
  };
};
